
<script src="chosen_v1.8.7/jquery.min.js"></script>
<script src="chosen_v1.8.7/chosen.jquery.js"></script>
<link href="chosen_v1.8.7/chosen.css" rel="stylesheet"/>

<script>
    // Correct Chosen initialization
    $(document).ready(function () {
        $("#software").chosen();
        $("#hardware").chosen();
        $("#hardware2").chosen();
        $("#hardware3").chosen();
    });
   
</script>